import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ContentService } from '../../core/content.service';
import { Course, CourseLanguage } from '../../core/models';
import {
  RegisterModalComponent,
  RegisteredUser,
} from '../../shared/register-modal/register-modal.component';
import {
  StripeCheckoutModalComponent,
  StripeCartItem,
} from '../../shared/stripe-checkout-modal/stripe-checkout-modal.component';

@Component({
  selector: 'app-courses',
  standalone: true,
  imports: [CommonModule, RouterLink, RegisterModalComponent, StripeCheckoutModalComponent],
  templateUrl: './courses.component.html',
  styleUrl: './courses.component.css',
})
export class CoursesComponent {
  selectedLanguage: CourseLanguage = 'frances';

  // ---- Flujo de compra: registro -> pago ----
  readonly buyingCourse = signal<Course | null>(null);
  readonly registeredUser = signal<RegisteredUser | null>(null);
  readonly purchaseDone = signal(false);

  constructor(public content: ContentService) {}

  get filteredCourses() {
    return this.content
      .courses()
      .filter((c) => c.language === this.selectedLanguage);
  }

  get loading(): boolean {
    return this.content.coursesLoading();
  }

  get loadError(): boolean {
    return this.content.coursesError();
  }

  setLanguage(lang: CourseLanguage): void {
    this.selectedLanguage = lang;
  }

  // Paso 1: abre el modal de registro para este curso
  comprar(course: Course): void {
    this.purchaseDone.set(false);
    this.buyingCourse.set(course);
  }

  // Paso 2: cuando el registro termina bien, pasa al pago
  onRegistered(user: RegisteredUser): void {
    this.registeredUser.set(user);
  }

  // Items para el modal de Stripe, a partir del curso que se está comprando
  get paymentItems(): StripeCartItem[] {
    const course = this.buyingCourse();
    if (!course?.id || !course?.tipoProductoId) return [];
    return [{ product_id: course.id, product_type: course.tipoProductoId }];
  }

  get paymentTotalLabel(): string {
    return this.buyingCourse()?.price ?? '';
  }

  onPaymentSuccess(): void {
    this.purchaseDone.set(true);
    this.buyingCourse.set(null);
    this.registeredUser.set(null);
  }

  closeBuyFlow(): void {
    this.buyingCourse.set(null);
    this.registeredUser.set(null);
  }
}
